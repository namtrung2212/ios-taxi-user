//
//  Driver.Profile.Comment.Cell.swift
//  User.iPhone
//
//  Created by Trung Dao on 6/3/16.
//  Copyright © 2016 SCONNECTING. All rights reserved.
//

import UIKit
import Foundation
import ObjectMapper
import AlamofireObjectMapper
import SClientData
import SClientModel
import CoreLocation
import RealmSwift
import GoogleMaps

import SClientUI
import SClientModelControllers
import DTTableViewManager
import DTModelStorage
import AlamofireImage

public class MenuItemCell: UITableViewCell, ModelTransfer {
    
    public var lblCaption: UILabel!
    public var lblDesc: UILabel!
    
    public var imgLeft: UIImageView!
    public var imgRight: UIImageView!
    
    public var topLine: CAShapeLayer!
    public var bottomLine: CAShapeLayer!
    
    public override init(style: UITableViewCellStyle, reuseIdentifier: String?){
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        self.selectionStyle = UITableViewCellSelectionStyle.None
        self.backgroundView =  UIView()
        self.backgroundColor = UIColor.whiteColor()
        
        lblCaption = UILabel(frame: CGRectMake(0, 0, 0, 50))
        lblCaption.font = UIFont(name: "HelveticaNeue", size: 11)
        lblCaption.textColor = UIColor.blackColor()
        lblCaption.textAlignment = NSTextAlignment.Left
        lblCaption.backgroundColor = UIColor.clearColor()
        lblCaption.translatesAutoresizingMaskIntoConstraints = false
        
        self.contentView.addSubview(lblCaption)
        lblCaption.centerYAnchor.constraintEqualToAnchor(self.contentView.centerYAnchor, constant : 0.0).active = true
        lblCaption.centerXAnchor.constraintEqualToAnchor(self.contentView.centerXAnchor, constant : 40.0).active = true
        lblCaption.widthAnchor.constraintEqualToAnchor(self.contentView.widthAnchor, constant : -15.0).active = true
        lblCaption.heightAnchor.constraintEqualToConstant(25.0).active = true
        
        imgLeft = UIImageView()
        imgLeft.translatesAutoresizingMaskIntoConstraints = false
        
        self.contentView.addSubview(imgLeft)
        imgLeft.centerYAnchor.constraintEqualToAnchor(self.contentView.centerYAnchor, constant : 0.0).active = true
        imgLeft.leftAnchor.constraintEqualToAnchor(self.contentView.leftAnchor, constant : 10.0).active = true
        imgLeft.widthAnchor.constraintEqualToConstant(25.0).active = true
        imgLeft.heightAnchor.constraintEqualToConstant(25.0).active = true

        
        self.accessoryType = UITableViewCellAccessoryType.DisclosureIndicator
    }
    
    public required init?(coder aDecoder: NSCoder){
        super.init(coder: aDecoder)
        
    }
    
    override public func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
    
    public  func updateWithModel(item: MenuItemObject) {
        
        self.lblCaption.text = item.Caption.uppercaseString
        
        if(item.Index != 0 && topLine == nil){
            topLine = CAShapeLayer()
            topLine.fillColor = UIColor.grayColor().CGColor
            topLine.path = UIBezierPath(roundedRect: CGRect(x: 40, y: 0 , width: SlideMenuOptions.leftViewWidth, height: 0.5), cornerRadius: 0).CGPath
            self.backgroundView?.layer.addSublayer(topLine)
        }
        
        if(item.leftIcon == "NewTravel"){
            self.imgLeft.setFAIconWithName(FAType.FAPlusCircle, textColor: UIColor(red: 73.0/255.0, green: 139.0/255.0, blue: 199.0/255.0, alpha: 1.0))
        }else if(item.leftIcon == "NotYetPickup"){
            self.imgLeft.setFAIconWithName(FAType.FAStreetView, textColor: UIColor(red: 73.0/255.0, green: 139.0/255.0, blue: 199.0/255.0, alpha: 1.0))
        }else if(item.leftIcon == "OnTheWay"){
            self.imgLeft.setFAIconWithName(FAType.FARandom, textColor: UIColor(red: 73.0/255.0, green: 139.0/255.0, blue: 199.0/255.0, alpha: 1.0))
        }else if(item.leftIcon == "NotYetPaid"){
            self.imgLeft.setFAIconWithName(FAType.FACreditCard, textColor: UIColor(red: 73.0/255.0, green: 139.0/255.0, blue: 199.0/255.0, alpha: 1.0))
        }else if(item.leftIcon == "History"){
            self.imgLeft.setFAIconWithName(FAType.FAHistory, textColor: UIColor(red: 73.0/255.0, green: 139.0/255.0, blue: 199.0/255.0, alpha: 1.0))
        }
    }

    
}

