//
//  Driver.Profile.Comment.Cell.swift
//  User.iPhone
//
//  Created by Trung Dao on 6/3/16.
//  Copyright © 2016 SCONNECTING. All rights reserved.
//

import UIKit
import Foundation
import ObjectMapper
import AlamofireObjectMapper
import SClientData
import SClientModel
import SClientUI
import CoreLocation
import RealmSwift
import GoogleMaps

import SClientModelControllers
import DTTableViewManager
import DTModelStorage
import AlamofireImage

public class MenuHeaderCell: UITableViewHeaderFooterView, ModelTransfer {
    
    public var lblCaption: UILabel!
    
    public var topLine: CAShapeLayer!
    public var bottomLine: CAShapeLayer!
    
    public var imgLeft: UIImageView!

    
    public override init(reuseIdentifier: String?){
        super.init( reuseIdentifier: reuseIdentifier)
        
        self.backgroundView =  UIView()
        self.backgroundView!.backgroundColor = UIColor(red: CGFloat(236/255.0), green: CGFloat(236/255.0), blue: CGFloat(236/255.0), alpha: 1.0)
        
        lblCaption = UILabel(frame: CGRectMake(0, 0, 0, 50))
        lblCaption.font = UIFont(name: "HelveticaNeue-Bold", size: 13)
        lblCaption.textColor = UIColor.darkGrayColor()
        lblCaption.textAlignment = NSTextAlignment.Center
        
        lblCaption.translatesAutoresizingMaskIntoConstraints = false
        
        self.contentView.addSubview(lblCaption)
        lblCaption.centerYAnchor.constraintEqualToAnchor(self.contentView.centerYAnchor, constant : 0.0).active = true
        lblCaption.centerXAnchor.constraintEqualToAnchor(self.contentView.centerXAnchor, constant : 0.0).active = true
      //  lblCaption.widthAnchor.constraintEqualToAnchor(self.contentView.widthAnchor, constant : -15.0).active = true
        lblCaption.heightAnchor.constraintEqualToConstant(25.0).active = true
        
        imgLeft = UIImageView()
        imgLeft.translatesAutoresizingMaskIntoConstraints = false
        
        self.contentView.addSubview(imgLeft)
        imgLeft.centerYAnchor.constraintEqualToAnchor(self.contentView.centerYAnchor, constant : 0.0).active = true
        imgLeft.leftAnchor.constraintEqualToAnchor(self.lblCaption.leftAnchor, constant : -40.0).active = true
        imgLeft.widthAnchor.constraintEqualToConstant(25.0).active = true
        imgLeft.heightAnchor.constraintEqualToConstant(25.0).active = true
        

        
        topLine = CAShapeLayer()
        topLine.fillColor = UIColor.grayColor().CGColor
        topLine.path = UIBezierPath(roundedRect: CGRect(x: 0, y: 0 , width: SlideMenuOptions.leftViewWidth, height: 0.5), cornerRadius: 0).CGPath
        self.backgroundView?.layer.addSublayer(topLine)
        
        bottomLine = CAShapeLayer()
        bottomLine.fillColor = UIColor.grayColor().CGColor
        bottomLine.path = UIBezierPath(roundedRect: CGRect(x: 0, y: 40 , width: SlideMenuOptions.leftViewWidth, height: 0.5), cornerRadius: 0).CGPath
        self.backgroundView?.layer.addSublayer(bottomLine)

    }
    
    public required init?(coder aDecoder: NSCoder){
        super.init(coder: aDecoder)
        
    }
    
    
    public  func updateWithModel(model: (String, String)) {
       
        self.lblCaption.text = model.0.uppercaseString
        self.lblCaption.sizeToFit()
        
        if(model.1 == "Taxi"){
            
            self.imgLeft.setFAIconWithName(FAType.FACar, textColor: UIColor(red: 73.0/255.0, green: 139.0/255.0, blue: 199.0/255.0, alpha: 1.0))
            
        }else if(model.1 == "TripMate"){
            
            self.imgLeft.setFAIconWithName(FAType.FAUsers, textColor: UIColor(red: 73.0/255.0, green: 139.0/255.0, blue: 199.0/255.0, alpha: 1.0))
            
        }
    }
    
    
}

