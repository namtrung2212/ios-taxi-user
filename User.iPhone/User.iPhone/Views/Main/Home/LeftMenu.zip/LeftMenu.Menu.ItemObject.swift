//
//  LeftMenu.Menu.ItemObject.swift
//  User.iPhone
//
//  Created by Trung Dao on 7/13/16.
//  Copyright © 2016 SCONNECTING. All rights reserved.
//

import Foundation

public class MenuItemObject{

    public var Index: Int
    public var Section: Int
    public var Caption: String
    public var Desc : String?
    public var leftIcon: String?
    public var rightIcon: String?
    
    public var height : Double = 25
    
    init( caption: String, section: Int, index: Int){
        
        self.Caption = caption
        self.Section = section
        self.Index = index
    }
    
    init( caption: String, section: Int, index: Int, leffImage: String){
        
        self.Caption = caption
        self.Section = section
        self.Index = index
        self.leftIcon = leffImage
    }
}