//
//  Driver.Profile.Comment.swift
//  User.iPhone
//
//  Created by Trung Dao on 6/1/16.
//  Copyright © 2016 SCONNECTING. All rights reserved.
//

import UIKit
import Foundation
import ObjectMapper
import AlamofireObjectMapper
import SClientData
import SClientModel
import CoreLocation
import RealmSwift
import GoogleMaps

import SClientModelControllers
import DTTableViewManager
import DTModelStorage
import AlamofireImage


public class MainMenu : UITableViewController, DTTableViewManageable {
    
    public var parent: LeftMenuViewController
    
    var rowHeights : [NSIndexPath: CGFloat] = [:]
    
    public init(parent: LeftMenuViewController){
        
        self.parent = parent
        super.init(style: .Grouped)
            
        
        manager.startManagingWithDelegate(self)
        manager.registerCellClass(MenuItemCell)
        manager.registerNiblessHeaderClass(MenuHeaderCell)
        manager.cellSelection(MainMenu.selectedItem)
        
    }
    
    public func initControls(){
        
        self.tableView.translatesAutoresizingMaskIntoConstraints = false
        self.tableView.separatorStyle = UITableViewCellSeparatorStyle.None
        self.tableView.backgroundColor = UIColor.whiteColor()
        self.tableView.scrollEnabled = false
        
    }
    
    public func initLayout(){
        
        self.parent.scrollView.addSubview(self.tableView)
        self.tableView.widthAnchor.constraintEqualToAnchor(self.parent.scrollView.widthAnchor , constant : 0.0).active = true
        self.tableView.centerXAnchor.constraintEqualToAnchor(self.parent.lblUserName.centerXAnchor, constant: 0).active = true
        self.tableView.topAnchor.constraintEqualToAnchor(self.parent.lblUserName.bottomAnchor, constant: 15).active = true
        self.tableView.heightAnchor.constraintEqualToConstant(2000).active = true
       
        
    }
    
    public func invalidate(){
        
        self.rowHeights.removeAll()
        
        
        manager.memoryStorage.removeAllItems()
        
        manager.memoryStorage.sections.removeAll()
        
        manager.memoryStorage.setSectionHeaderModel(("Gọi Taxi","Taxi"), forSectionIndex: 0)
        
        manager.memoryStorage.addItem(MenuItemObject(caption: "Tạo hành trình", section: 0, index: 0,leffImage: "NewTravel" ), toSection: 0)
        manager.memoryStorage.addItem(MenuItemObject(caption: "Chưa khởi hành", section: 0, index: 1,leffImage: "NotYetPickup"), toSection: 0)
        manager.memoryStorage.addItem(MenuItemObject(caption: "Trong hành trình", section: 0, index: 2,leffImage: "OnTheWay"), toSection: 0)
        manager.memoryStorage.addItem(MenuItemObject(caption: "Chưa thanh toán", section: 0, index: 3,leffImage: "NotYetPaid"), toSection: 0)
        manager.memoryStorage.addItem(MenuItemObject(caption: "Lịch sử", section: 0, index: 4,leffImage: "History"), toSection: 0)
        
        
        manager.memoryStorage.setSectionHeaderModel(("Đi chung","TripMate"), forSectionIndex: 1)
        
        manager.memoryStorage.addItem(MenuItemObject(caption: "Tạo yêu cầu", section: 1, index: 0), toSection: 1)
        manager.memoryStorage.addItem(MenuItemObject(caption: "Cộng đồng", section: 1, index: 1), toSection: 1)
        manager.memoryStorage.addItem(MenuItemObject(caption: "Chưa có nhóm", section: 1, index: 2), toSection: 1)
        manager.memoryStorage.addItem(MenuItemObject(caption: "Đã có nhóm", section: 1, index: 3), toSection: 1)
        manager.memoryStorage.addItem(MenuItemObject(caption: "Tin nhắn", section: 1, index: 4), toSection: 1)
        manager.memoryStorage.addItem(MenuItemObject(caption: "Thông báo", section: 1, index: 5), toSection: 1)
        
        
        
        manager.memoryStorage.setSectionHeaderModel(("Thẻ thanh toán","PaymentMethod"), forSectionIndex: 2)
        
        manager.memoryStorage.addItem(MenuItemObject(caption: "Tạo thẻ mới", section: 2, index: 0), toSection: 2)
        manager.memoryStorage.addItem(MenuItemObject(caption: "Danh sách thẻ", section: 2, index: 1), toSection: 2)
        manager.memoryStorage.addItem(MenuItemObject(caption: "Tài khoản", section: 2, index: 2), toSection: 2)
        manager.memoryStorage.addItem(MenuItemObject(caption: "Cấp hạn mức", section: 2, index: 3), toSection: 2)
        manager.memoryStorage.addItem(MenuItemObject(caption: "Lịch sử dùng thẻ", section: 2, index: 4), toSection: 2)
        
        self.parent.resetScrollSize()
        
    }
    
    public func selectedItem(cell: MenuItemCell, item: MenuItemObject, indexPath: NSIndexPath) {
        
        UIView.animateWithDuration(0.1 ,
                                   animations: {
                                    cell.transform = CGAffineTransformMakeScale(0.9, 0.9)
            },
                                   completion: { finish in
                                    UIView.animateWithDuration(0.1){
                                        cell.transform = CGAffineTransformIdentity
                                    }
                                    
                                    self.parent.menuItem_Clicked(item)
                                    
                                   
        })
        
        
    }

    public func getPreferedTableHeight() -> CGFloat{
        self.tableView.layoutIfNeeded()
        
        var height : CGFloat = 0
        manager.memoryStorage.sections.forEach { (section) in
            
            height += CGFloat(section.numberOfItems * 40)
            height += CGFloat(40)
        }
       return height
        
    }
    
    public override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat{

        return 40
        
    }
    
    public override func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        
        return 40
    }
    
    public override func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath){
        
        let lastSectionIndex = tableView.numberOfSections - 1
        let lastRowIndex = tableView.numberOfRowsInSection(lastSectionIndex) - 1
        
        if ((indexPath.section == lastSectionIndex) && (indexPath.row == lastRowIndex)) {
            
            
        }
        
    }
    
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
