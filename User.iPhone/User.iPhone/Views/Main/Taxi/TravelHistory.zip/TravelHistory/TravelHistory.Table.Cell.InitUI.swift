//
//  Driver.Profile.Comment.Cell.swift
//  User.iPhone
//
//  Created by Trung Dao on 6/3/16.
//  Copyright © 2016 SCONNECTING. All rights reserved.
//

import UIKit
import Foundation
import ObjectMapper
import AlamofireObjectMapper
import SClientData
import SClientModel
import CoreLocation
import RealmSwift
import GoogleMaps

import SClientModelControllers
import DTTableViewManager
import DTModelStorage
import AlamofireImage
import GoogleMaps

public class TravelOrderCell: UITableViewCell, ModelTransfer,GMSMapViewDelegate {
    
    
    var lblStatus: UILabel!
    var lblCurrentPrice: UILabel!
    
    var btnPickupIcon: UIButton!
    var lblPickupLocation: UILabel!
    
    var btnDropIcon: UIButton!
    var lblDropLocation: UILabel!
    
    var lblDateTime: UILabel!
    var pnlCellArea: UIView!
    var pnlBottomInfoArea: UIView!
    
    
    var gmsMapView: GMSMapView!
    var pathPolyLine : GMSPolyline?
    
    var mSourceMarker : GMSMarker!
    var mDestinyMarker : GMSMarker!
    
    public override init(style: UITableViewCellStyle, reuseIdentifier: String?){
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        self.selectionStyle = UITableViewCellSelectionStyle.None
        self.backgroundView =  UIView()
        self.backgroundColor = UIColor.clearColor()
        
        self.contentView.backgroundColor = UIColor.clearColor()
        
        self.initControls{
            self.initLayouts({ 
                
                
            })
        }
    }
    
    func initControls(completion: (() -> ())?){
        
        let scrRect = UIScreen.mainScreen().bounds
        
        pnlCellArea = UIView()
        pnlCellArea.backgroundColor = UIColor.whiteColor()
       // pnlCellArea.layer.borderColor = UIColor.grayColor().CGColor
        //pnlCellArea.layer.borderWidth = 0.5
        pnlCellArea.layer.shadowOffset = CGSize(width: 2, height: 2)
        pnlCellArea.layer.shadowOpacity = 0.5
        pnlCellArea.layer.shadowRadius = 3
        pnlCellArea.translatesAutoresizingMaskIntoConstraints = false
        pnlCellArea.alpha = 1.0
        pnlCellArea.userInteractionEnabled = true
        
        pnlBottomInfoArea = UIView()
        pnlBottomInfoArea.backgroundColor = UIColor.whiteColor()
        pnlBottomInfoArea.translatesAutoresizingMaskIntoConstraints = false
        pnlBottomInfoArea.alpha = 1.0
        pnlBottomInfoArea.userInteractionEnabled = true
        

        // Source Point Left Button
        let imgSource = ImageHelper.resize(UIImage(named: "pickupIcon.png")!, newWidth: 25)
        btnPickupIcon   = UIButton(type: UIButtonType.Custom) as UIButton
        btnPickupIcon.frame = CGRectMake(25, 25, 25, 25)
        btnPickupIcon.setImage(imgSource, forState: .Normal)
        btnPickupIcon.translatesAutoresizingMaskIntoConstraints = false
        
        // Source Point Label
        lblPickupLocation   =  UILabel(frame: CGRectMake(0, 0, 0, 50))
        lblPickupLocation.frame = CGRectMake(0, 0, 0, 10)
        lblPickupLocation.text = ""
        lblPickupLocation.textColor = UIColor.darkGrayColor()
        lblPickupLocation.font = lblPickupLocation.font.fontWithSize(12)
        lblPickupLocation.textAlignment = NSTextAlignment.Left
        lblPickupLocation.translatesAutoresizingMaskIntoConstraints = false
        
        // Destiny Point Left Button
        let imgDrop = ImageHelper.resize(UIImage(named: "dropicon.png")!, newWidth: 25)
        btnDropIcon   = UIButton(type: UIButtonType.Custom) as UIButton
        btnDropIcon.frame = CGRectMake(25, 25, 25, 25)
        btnDropIcon.setImage(imgDrop, forState: .Normal)
        btnDropIcon.translatesAutoresizingMaskIntoConstraints = false
        
        // Destiny Point Label
        lblDropLocation   =  UILabel(frame: CGRectMake(0, 0, 0, 50))
        lblDropLocation.frame = CGRectMake(0, 0, 0, 10)
        lblDropLocation.text = ""
        lblDropLocation.textColor = UIColor.darkGrayColor()
        lblDropLocation.font = lblDropLocation.font.fontWithSize(12)
        lblDropLocation.textAlignment = NSTextAlignment.Left
        lblDropLocation.translatesAutoresizingMaskIntoConstraints = false
        
        // Path Statistic Label
        lblDateTime = UILabel(frame: CGRectMake(0, 0, 0, 50))
        lblDateTime.font = UIFont(name: "HelveticaNeue", size: 12)
        lblDateTime.textColor = UIColor.darkGrayColor()
        lblDateTime.textAlignment = NSTextAlignment.Left
        lblDateTime.text = ""
        lblDateTime.translatesAutoresizingMaskIntoConstraints = false
        
        
        lblStatus = UILabel(frame: CGRectMake(0, 0, 0, 50))
        lblStatus.font = UIFont(name: "HelveticaNeue-Bold", size: 11)
        lblStatus.textColor = UIColor(red: 73.0/255.0, green: 139.0/255.0, blue: 199.0/255.0, alpha: 1.0)
        lblStatus.textAlignment = NSTextAlignment.Center
        lblStatus.text = ""
        lblStatus.translatesAutoresizingMaskIntoConstraints = false
        
        lblCurrentPrice = UILabel(frame: CGRectMake(0, 0, 0, 50))
        lblCurrentPrice.font = UIFont(name: "HelveticaNeue-Bold", size: 17)
        lblCurrentPrice.textColor = UIColor.darkGrayColor()
        lblCurrentPrice.textAlignment = NSTextAlignment.Right
        lblCurrentPrice.text = ""
        lblCurrentPrice.translatesAutoresizingMaskIntoConstraints = false

        let camera  = GMSCameraPosition.cameraWithLatitude(0.702812, longitude: 106.643604, zoom: 15)
        
        gmsMapView = GMSMapView.mapWithFrame(CGRectMake(10,10,scrRect.size.width * 0.9, 220), camera: camera)
        gmsMapView.myLocationEnabled = false
        gmsMapView.settings.myLocationButton = false
        gmsMapView.settings.scrollGestures = false
        gmsMapView.settings.zoomGestures = false
        gmsMapView.settings.tiltGestures = false
        gmsMapView.settings.rotateGestures = false
        gmsMapView.userInteractionEnabled = false
        gmsMapView.mapType = kGMSTypeNormal        
        gmsMapView.delegate = self
        gmsMapView.padding = UIEdgeInsets(top: 5, left: 5,bottom: 5, right: 5)
        
        
        
        
        mSourceMarker = GMSMarker(position: CLLocationCoordinate2D(latitude: 0, longitude: 0))
        mSourceMarker.title = "Điểm đi"
        let imgSourcePin =  ImageHelper.resize(UIImage(named: "sourcePin.png")!, newWidth: 35)
        let sourcePinView = UIImageView(image: imgSourcePin)
        mSourceMarker.iconView = sourcePinView
        mSourceMarker.groundAnchor = CGPointMake(0.5, 1);
        mSourceMarker.tracksViewChanges = true
        mSourceMarker.map = self.gmsMapView
        
        mDestinyMarker = GMSMarker(position: CLLocationCoordinate2D(latitude: 0, longitude: 0))
        mDestinyMarker.title = "Điểm đến"
        let imgDestinyPin =  ImageHelper.resize(UIImage(named: "destinyPin.png")!, newWidth: 35)
        let destinyPinView = UIImageView(image: imgDestinyPin)
        mDestinyMarker.iconView = destinyPinView
        mDestinyMarker.groundAnchor = CGPointMake(0.5, 1);
        mDestinyMarker.tracksViewChanges = true
        mDestinyMarker.map = self.gmsMapView
        

        completion?()
    }
    
    func initLayouts(completion: (() -> ())?){
        
        
        let scrRect = UIScreen.mainScreen().bounds
        
        self.contentView.addSubview(pnlCellArea)
        pnlCellArea.topAnchor.constraintEqualToAnchor(self.contentView.topAnchor, constant: 10.0).active = true
        pnlCellArea.bottomAnchor.constraintEqualToAnchor(contentView.bottomAnchor, constant : -10.0).active = true
        pnlCellArea.widthAnchor.constraintEqualToAnchor(contentView.widthAnchor, multiplier: 0.95).active = true
        pnlCellArea.centerXAnchor.constraintEqualToAnchor(contentView.centerXAnchor, constant : 0.0).active = true
        
        self.pnlCellArea.addSubview(gmsMapView)
        gmsMapView.centerXAnchor.constraintEqualToAnchor(pnlCellArea.centerXAnchor, constant : 0.0).active = true
        gmsMapView.topAnchor.constraintEqualToAnchor(self.pnlCellArea.topAnchor, constant: 15.0).active = true
        gmsMapView.widthAnchor.constraintEqualToAnchor(pnlCellArea.widthAnchor, multiplier: 0.9).active = true
        gmsMapView.heightAnchor.constraintEqualToConstant(220).active = true

        
        self.pnlCellArea.addSubview(pnlBottomInfoArea)
        pnlBottomInfoArea.topAnchor.constraintEqualToAnchor(gmsMapView.bottomAnchor, constant : 10.0).active = true
        pnlBottomInfoArea.widthAnchor.constraintEqualToAnchor(pnlCellArea.widthAnchor, multiplier: 0.95).active = true
        pnlBottomInfoArea.centerXAnchor.constraintEqualToAnchor(pnlCellArea.centerXAnchor, constant : 0.0).active = true
        pnlBottomInfoArea.heightAnchor.constraintEqualToConstant(85).active = true
        
       let topLine = CAShapeLayer()
        topLine.fillColor = UIColor.grayColor().CGColor
        topLine.path = UIBezierPath(roundedRect: CGRect(x: 0, y: 0 , width: scrRect.width * 0.95 * 0.95, height: 0.5), cornerRadius: 0).CGPath
        self.pnlBottomInfoArea?.layer.addSublayer(topLine)
        
        self.pnlBottomInfoArea.addSubview(lblPickupLocation)
        lblPickupLocation.topAnchor.constraintEqualToAnchor(self.pnlBottomInfoArea.topAnchor, constant: 10.0).active = true
        lblPickupLocation.leftAnchor.constraintEqualToAnchor(pnlBottomInfoArea.leftAnchor, constant : 40.0).active = true
        lblPickupLocation.widthAnchor.constraintEqualToAnchor(pnlBottomInfoArea.widthAnchor, constant : -40.0).active = true
        lblPickupLocation.heightAnchor.constraintEqualToConstant(13).active = true

        self.pnlBottomInfoArea.addSubview(btnPickupIcon)
        btnPickupIcon.leftAnchor.constraintEqualToAnchor(pnlBottomInfoArea.leftAnchor, constant : 10.0).active = true
        btnPickupIcon.centerYAnchor.constraintEqualToAnchor(lblPickupLocation.centerYAnchor, constant: 0.0).active = true
        btnPickupIcon.heightAnchor.constraintEqualToConstant(25).active = true
        
        self.pnlBottomInfoArea.addSubview(lblDropLocation)
        lblDropLocation.topAnchor.constraintEqualToAnchor(lblPickupLocation.bottomAnchor, constant : 15.0).active = true
        lblDropLocation.leftAnchor.constraintEqualToAnchor(lblPickupLocation.leftAnchor, constant : 0.0).active = true
        lblDropLocation.widthAnchor.constraintEqualToAnchor(lblPickupLocation.widthAnchor, constant : 0.0).active = true
        lblDropLocation.heightAnchor.constraintEqualToConstant(13).active = true
        
        self.pnlBottomInfoArea.addSubview(btnDropIcon)
        btnDropIcon.centerYAnchor.constraintEqualToAnchor(lblDropLocation.centerYAnchor, constant: 0.0).active = true
        btnDropIcon.leftAnchor.constraintEqualToAnchor(btnPickupIcon.leftAnchor, constant : 0.0).active = true
        btnDropIcon.heightAnchor.constraintEqualToConstant(25).active = true
        
        
        self.pnlBottomInfoArea.addSubview(lblDateTime)
        lblDateTime.topAnchor.constraintEqualToAnchor(self.lblDropLocation.bottomAnchor, constant: 12.0).active = true
        lblDateTime.leftAnchor.constraintEqualToAnchor(btnDropIcon.leftAnchor, constant : 0.0).active = true
        lblDateTime.widthAnchor.constraintEqualToAnchor(lblDropLocation.widthAnchor, multiplier: 0.95).active = true
        lblDateTime.heightAnchor.constraintEqualToConstant(15).active = true

        
        self.pnlBottomInfoArea.addSubview(lblCurrentPrice)
        lblCurrentPrice.bottomAnchor.constraintEqualToAnchor(self.lblDateTime.bottomAnchor, constant: 0.0).active = true
        lblCurrentPrice.rightAnchor.constraintEqualToAnchor(pnlBottomInfoArea.rightAnchor, constant : -10.0).active = true
        lblCurrentPrice.heightAnchor.constraintEqualToConstant(15).active = true
        lblCurrentPrice.widthAnchor.constraintEqualToConstant(100).active = true
        
        self.pnlBottomInfoArea.addSubview(lblStatus)
        lblStatus.bottomAnchor.constraintEqualToAnchor(lblDateTime.bottomAnchor, constant: 3.0).active = true
        lblStatus.centerXAnchor.constraintEqualToAnchor(pnlBottomInfoArea.centerXAnchor, constant : 0.0).active = true
        lblStatus.heightAnchor.constraintEqualToConstant(15).active = true
        lblStatus.widthAnchor.constraintEqualToAnchor(pnlBottomInfoArea.widthAnchor, multiplier: 0.95).active = true
        
        
        self.contentView.layoutIfNeeded()
        completion?()
    }
    
    public required init?(coder aDecoder: NSCoder){
        super.init(coder: aDecoder)
        
    }
    
    override public func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
}

