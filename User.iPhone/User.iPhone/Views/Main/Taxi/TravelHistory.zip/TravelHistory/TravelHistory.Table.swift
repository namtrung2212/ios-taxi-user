//
//  Driver.Profile.Comment.swift
//  User.iPhone
//
//  Created by Trung Dao on 6/1/16.
//  Copyright © 2016 SCONNECTING. All rights reserved.
//

import UIKit
import Foundation
import ObjectMapper
import AlamofireObjectMapper
import SClientData
import SClientModel
import CoreLocation
import RealmSwift
import GoogleMaps

import SClientModelControllers
import DTTableViewManager
import DTModelStorage
import AlamofireImage


public class TravelHistoryTable : UITableViewController, DTTableViewManageable {
    
    public var parent: TravelHistoryScreen
    
    var currentPages = 1
    public init(parent: TravelHistoryScreen){
        
        self.parent = parent
        super.init(nibName: nil, bundle: nil)
        
        
        self.refreshControl = UIRefreshControl()
        self.refreshControl!.addTarget(self, action: "refresh:", forControlEvents: .ValueChanged)
        self.tableView.addSubview(self.refreshControl!)
        
        manager.startManagingWithDelegate(self)
        manager.registerCellClass(TravelOrderCell)
        manager.cellSelection(TravelHistoryTable.selectedItem)
        
    }
    
    public func selectedItem(cell: TravelOrderCell, item: TravelOrder, indexPath: NSIndexPath) {
        
        UIView.animateWithDuration(0.1 ,
                                   animations: {
                                    cell.transform = CGAffineTransformMakeScale(0.9, 0.9)
            },
                                   completion: { finish in
                                    UIView.animateWithDuration(0.1){
                                        cell.transform = CGAffineTransformIdentity
                                    }
                                    
                                    self.parent.navigationController?.popViewControllerAnimated(true)
                                    SCONNECTING.TaxiManager!.reset(item, updateUI: true){
                                        AppDelegate.mainWindow?.mainViewCtrl.taxiViewCtrl.hideNavigationBar(false)
                                        AppDelegate.mainWindow?.mainViewCtrl.taxiViewCtrl.monitoringView.chattingView.chattingTable.refreshList()
                                    }
                                    
        })
        
        
    }
    

    public func initControls(completion: (() -> ())?){
        
        self.tableView.translatesAutoresizingMaskIntoConstraints = false
        self.tableView.separatorStyle = UITableViewCellSeparatorStyle.None
        self.tableView.backgroundColor = UIColor(red: 222/255.0, green: 220/255.0, blue: 222/255.0, alpha: 1.0)
        completion?()
    }
    
    public func initLayout(completion: (() -> ())?){
        
        self.parent.view.addSubview(self.tableView)
        self.tableView.widthAnchor.constraintEqualToAnchor(self.parent.view.widthAnchor , constant : 0.0).active = true
        self.tableView.centerXAnchor.constraintEqualToAnchor(self.parent.view.centerXAnchor, constant: 0).active = true
        self.tableView.topAnchor.constraintEqualToAnchor(self.parent.view.topAnchor, constant: 60).active = true
        self.tableView.bottomAnchor.constraintEqualToAnchor(self.parent.view.bottomAnchor, constant: 0).active = true
        
        completion?()
    }
    
    func refresh(refreshControl: UIRefreshControl) {
        
        self.invalidate()
        refreshControl.endRefreshing()
    }
    
    public func invalidate(){
        
        currentPages = 1
        
        self.manager.memoryStorage.removeAllItems()
        TravelOrderController.GetAllOrderByUser(SCONNECTING.UserManager!.CurrentUser!.id!,page: currentPages, pagesize: 10) { (orders) in
            self.parent.lblNoTravel.hidden = (orders.count > 0)
            self.manager.memoryStorage.addItems(orders)
            
            self.loadMores()
        }
        
    }
    
    
    public func loadMores(){
        
        
        if(currentPages < 0){
            return
        }
        
        //self.parent.btnLoadMore.hidden = (currentPages <= 0)
        currentPages += 1
        
        TravelOrderController.GetAllOrderByUser(SCONNECTING.UserManager!.CurrentUser!.id!,page: currentPages, pagesize: 10) { (orders) in
            if(orders.count > 0){
                
                self.manager.memoryStorage.addItems(orders)
                
            }else{
                self.currentPages = -1
            }
        }
        
    }
    
    
    
    public override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat{
        
        let scrRect = UIScreen.mainScreen().bounds
        
        let model = self.manager.storage.itemAtIndexPath(indexPath)! as! TravelOrder
        
        return 350
        
    }
    
    public override func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath){
        
        let lastSectionIndex = tableView.numberOfSections - 1
        let lastRowIndex = tableView.numberOfRowsInSection(lastSectionIndex) - 1
        
        if ((indexPath.section == lastSectionIndex) && (indexPath.row == lastRowIndex)) {
            self.loadMores()
        }
        
    }
    
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
