//
//  TripMateViewController.swift
//  User.iPhone
//
//  Created by Trung Dao on 4/13/16.
//  Copyright © 2016 SCONNECTING. All rights reserved.
//
import UIKit
import Foundation
import ObjectMapper
import AlamofireObjectMapper
import SClientData
import SClientModel
import CoreLocation
import RealmSwift
import GoogleMaps

public class TravelHistoryScreen: UIViewController {
    
    var historyTable: TravelHistoryTable!
    
    var lblNoTravel: UILabel!
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        
        self.initControls{
            
        }
    }
    
    
    func initControls(completion: (() -> ())?){
        
        
        let btnBack = UIBarButtonItem(title: "", style: .Plain, target: self, action: "btnBack_Clicked")
        btnBack.setFAIcon(FAType.FAArrowLeft, iconSize : 20)
        btnBack.setTitlePositionAdjustment(UIOffsetMake(0, -5), forBarMetrics: .Default)
        self.navigationItem.leftBarButtonItem = btnBack
        self.navigationItem.title = "Lịch sử gọi Taxi"
        
        let titleDict: NSDictionary = [NSForegroundColorAttributeName: UIColor.whiteColor()]
        self.navigationController!.navigationBar.titleTextAttributes = titleDict as? [String : AnyObject]
        
        
        lblNoTravel = UILabel(frame: CGRectMake(0, 0, 0, 50))
        lblNoTravel.font = UIFont(name: "HelveticaNeue", size: 14)
        lblNoTravel.textColor = UIColor.darkGrayColor()
        lblNoTravel.textAlignment = NSTextAlignment.Center
        lblNoTravel.text = "Bạn chưa gọi taxi lần nào."
        lblNoTravel.translatesAutoresizingMaskIntoConstraints = false
        lblNoTravel.hidden = true
        
        historyTable = TravelHistoryTable(parent: self)
        historyTable.initControls{
            self.historyTable.initLayout{
                
                self.view.addSubview(self.lblNoTravel)
                self.lblNoTravel.topAnchor.constraintEqualToAnchor(self.view.topAnchor, constant: 110.0).active = true
                self.lblNoTravel.centerXAnchor.constraintEqualToAnchor(self.view.centerXAnchor, constant : 0.0).active = true
                self.lblNoTravel.widthAnchor.constraintEqualToAnchor(self.view.widthAnchor, multiplier: 0.95).active = true
                self.lblNoTravel.heightAnchor.constraintEqualToConstant(15).active = true
                

                self.historyTable.invalidate()
                
                completion?()
            }
        }
        
        
    }
    
    
    public func btnBack_Clicked() {
        
        self.navigationController?.popViewControllerAnimated(true)
        AppDelegate.mainWindow?.leftViewCtrl.invalidate()
        AppDelegate.mainWindow?.mainViewCtrl.slideMenuController()?.openLeft()
        
    }
    
}
